"""
Common namespace of statistical functions
"""

# flake8: noqa

from pandas.stats.moments import *
